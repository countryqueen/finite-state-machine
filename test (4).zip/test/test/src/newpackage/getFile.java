/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package newpackage;
//here are the imports to create the jFile chooser
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import java.util.Scanner;
/**
 * Class Name: getFile
 * Class Author: Angelica Jones
 * ‘*** Purpose of the class: to open the file using the jfilechooser b/c it is easier than using drag and drop in jframe
 * Date 4/2/18
 * List of changes with dates. 
 * @author aj035
 */

public class getFile 
{
    //here are private variables
    private showFSM fsa;
    //this will call the GUI class
    private File textFile;
    private String strFile;
    private String fileName;
    private String scan;
    String theInput;
    public boolean isAccepted;
    private int startState;
    private ArrayList<Rule> rules;
    public int acceptingState;
    //here is the construcor
     public getFile(File textFile)
    {
        this.textFile = textFile;
        this.strFile = "";
    } 
    
    //this is a getter
    public String getFileName()
    {
        return fileName;
    }
    
    //this is a getter
    public String getScan()
    {
        return scan;
    }
    
     /* 
    Method Name: readFile()
    Method Input: none
    Parameters: none
    Purpose: creates input to FSM
    Return: none
    Date: 04/04/17
    */     
    //this method will read the string
    public void readFile() throws IOException 
    {
        String fileName = textFile.getAbsolutePath(); //gets file's path
        this.fileName = textFile.getName(); // gets simple name of the File and stores it in private variable
        
        FileInputStream fis = new FileInputStream(fileName);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        String line = null;
        
        ArrayList<String> linesList = new ArrayList<>();
        try 
        {
           while((line = br.readLine()) != null)
           {
               linesList.add(line);
           }
        } catch(Exception ie)
        {
            System.out.println("Something went wrong..");
        }
        finally 
        {
            br.close(); // closes file
        }
        //using an enhanced for loop to access the ArrayList as explained in the "Java" by Tony Gaddis
        for(String linee : linesList)
        {
            System.out.println("testing"+ linee);
        }
        
        //using regex to find specfic patterns. I am giving full credit to classmate Emily for assistance
        Scanner startScanner = new Scanner(linesList.get(0)).useDelimiter("[^0-9]+");
        startState = startScanner.nextInt();
        //saves the string as an integer
        
        System.out.println("start num test: " + startState);
        
        //linesList.get(specifies the index number of the array list) use.Delimiter (specifies the characters you are wanting to pull using the scanner
        Scanner acceptingScanner = new Scanner(linesList.get(1)).useDelimiter("[^0-9]+");
        acceptingState = acceptingScanner.nextInt();
        //saves the string as an integer
        
        System.out.println("accepting state num test: " + acceptingState);        
        
        rules = new ArrayList<>();
        ///the rules are printed out
        for(int i = 3; i < linesList.size(); i++)
        {
            Rule newRule = new Rule();
            
            //passing the char as an integer with the index #
            newRule.start = Integer.parseInt(Character.toString(linesList.get(i).charAt(2)));  //converts starting character to string to integer. Giving full credit to classmat Emily 
            newRule.letter = linesList.get(i).charAt(4);
            newRule.result = Integer.parseInt(Character.toString(linesList.get(i).charAt(9)));
            
            rules.add(newRule);
           // System.out.println("testing rules: " + newRule.start + newRule.letter + newRule.result);
            //linesList.get(i).charAt(4)+linesList.get(i).charAt(9));
        }
    } 
    
       /* 
    Method Name: setInput(String input)
    Method Input: String input
    Parameters: none
    Purpose: sets the user input to a string and calls the analyzeInput method
    Return: void
    Date: 04/14/17
    */   
    public void setInput(String input)
    {
        theInput = input;
        analyzeInput();
    }
     /* 
    Method Name: analyzeInput()
    Purpose: here is where finite state machine begins
    compare each user's letter to thte rules in the document until the whole word is checked.
    Return: void
    Date: 04/14/17
    */   
    //sets the boolean to true or false
    private void analyzeInput()
    {
       //declares variables
        int currentState = startState;
        char currentLetter;
        boolean keepChecking = true;
        boolean keepCheckingRules = true;
        isAccepted = true;
        
        ///match rules to each letter.
        //checking each letter of user input
        for(int i = 0; i < theInput.length() && keepChecking == true; i++)
        {
           // System.out.println("First for loop is here");
            currentLetter = theInput.charAt(i);
           // System.out.println("sizeeee: " + rules.size());
            keepCheckingRules = true;
            //checks the rules by comparing the letter that it is currently on
            for(int j = 0; j < rules.size()-1 && keepCheckingRules; j++)
            {
                if(rules.get(j).letter == currentLetter && currentState == rules.get(j).start)
                {
                    currentState = rules.get(j).result;
                    keepCheckingRules = false;
                    //ensures for loop goes to next character as stated by classmate Emily Farias
                }
                //checks for the last element 
                else if(j == rules.size()-1 && keepCheckingRules)
                {
                    isAccepted = false;
                    keepChecking = false;
                }
                
            }
            
            
        }

        //the ending state is the same as the accepting state then it is true!
        if(acceptingState == currentState)
        {
            isAccepted = true;
        }
        //otherwise it is false
        else
        {
            isAccepted = false;
        }

    }
        
}
  


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

/**
 *
 * /**
 * Class Name: Rule
 * Class Author: Angelica Jones
 * ‘*** Purpose of the class: store each of the rules, the starting state, the letter with it, and the resulting state
 * Date 4/12/18
 * List of changes with dates. 
 * @author aj035
 */

//creates the variables as the rules needed
public class Rule
{
    int start;
    char letter;
    int result;
}
